# UCIe Two-Die Package — Allegro X APD Plus 24.1 Workspace

**Status:** pin-map/import-data package prepared; native Allegro layout and routing remain to be executed and verified in APD Plus 24.1.

## Quick start
1. Read `05_Documentation/PROJECT_EXPLANATION.md`.
2. Review `05_Documentation/DESIGN_ASSUMPTIONS_AND_OPEN_ITEMS.md`.
3. Import the three tab-separated files in `03_Import_Files/` into APD Plus 24.1:
   - `D1_bump_import.txt`
   - `D2_bump_import.txt`
   - `package_ball_import.txt`
4. Use `03_Import_Files/ucie_die_to_die_connections.csv` to define the die-to-die UCIe link connectivity.
5. Follow `05_Documentation/ALLEGRO_APD24_1_WORKFLOW.md`.
6. Run `04_Scripts/validate_project.py` after modifying maps.

## Key dimensions
- Die bump: 40 µm diameter, 130 µm pitch.
- Package ball: 150 µm diameter, 400 µm pitch.
- D1/D2 bump map: 14 columns × 18 rows, 125 occupied sites per die.
- BGA: 10 × 10, 100 occupied balls.

## Folder guide
- `01_Bump_Maps/` — editable D1/D2 pin lists and logical grids.
- `02_Ball_Map/` — editable BGA map.
- `03_Import_Files/` — tab-separated APD import data and die-to-die logical connectivity.
- `04_Scripts/` — generator and validation scripts.
- `05_Documentation/` — project explanation, APD workflow, assumptions.
- `06_Visuals/` — map visualisations.
- `07_Allegro_Checklists/` — sign-off checklist.

## Coordinate and format note
Coordinates are in micrometres with lower-left origin. The text files use the six columns shown in the course brief. Confirm the coordinate units and `BI` pin-use code accepted by your installed APD Plus 24.1 import dialog. Do not import in mils/database units without conversion.

## What is not included
This archive does not contain an Allegro native `.brd`/package database, completed copper routing, DRC output, or SI sign-off. Those require the local licensed APD Plus environment, the correct technology/stack-up and missing die/package fabrication data. No routing or verification is claimed.
