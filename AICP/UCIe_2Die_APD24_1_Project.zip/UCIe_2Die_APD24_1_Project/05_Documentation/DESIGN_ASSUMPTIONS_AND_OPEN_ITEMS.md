# Design assumptions and open items

| Item | Workspace value | Status |
|---|---:|---|
| Bump diameter | 40 µm | From course brief |
| Bump pitch | 130 µm | From course brief |
| Ball diameter | 150 µm | From course brief |
| Ball pitch | 400 µm | From course brief |
| Bump grid | 14 × 18 | Transcribed from D1 handout map |
| D2 orientation | Horizontal mirror of D1 | Course brief page 5 |
| BGA grid | 10 × 10 | Transcribed from handout page 8 |
| Package outline | 8.0 × 5.0 mm | Placeholder proposal |
| Die body | 2.0 × 2.5 mm each | Placeholder proposal |
| Routing stack-up | 6 layers | Placeholder proposal |
| UCIe data rate | Not specified | Must be selected |
| Die dimensions / bump origin | Not supplied | Must obtain |
| Substrate material / dielectric | Not supplied | Must obtain |
| Copper thickness / via rules | Not supplied | Must obtain |
| Target impedance / length skew | Not supplied | Must derive from stack-up and channel budget |
| APD import unit and pin-use mapping | Assumed µm and BI | Confirm in local APD build |
| Native APD design database | Not generated | Requires APD Plus 24.1 |

## Important electrical consistency checks
- The handout's interface list abbreviates sideband signals; UCIe Table 5-17 includes both TXCKSB and RXCKSB. The D1/D2 bump maps include both directions.
- The bump maps use VCC, VCCIO, VCCAON and VSS labels. Confirm rail voltages and whether VCC is actually required by the die/package system.
- The handout's BGA map is an illustrative 10 × 10 assignment. Verify the final external pinout with the system schematic.
- The 16 GPIO pins are per die; the 100-ball array has a constrained count once power, JTAG and I²C are included. The supplied topology follows the handout and should be checked against the actual external interface requirements.
- A UCIe bump map is not enough to prove channel compliance. Physical routing, stack-up, length/skew and SI analysis are mandatory.
