# Allegro X APD Plus 24.1 — implementation workflow

This guide assumes a licensed APD Plus 24.1 installation and an approved package technology file / stack-up.

## A. Prepare and import the pin maps
1. Start Allegro X APD Plus 24.1 and create a new package/substrate design using the course's required technology/library.
2. Confirm the design database coordinate units. The provided text files use **micrometres**. Set the import unit accordingly or convert all X/Y values consistently.
3. Import `03_Import_Files/D1_bump_import.txt` as the D1 die bump/pin array. Map the six columns exactly:
   - Pin Number → pin number
   - X Coord → X
   - Y Coord → Y
   - Net Name → net
   - Pin Use → pin use
   - Rotation → rotation
4. Repeat for `D2_bump_import.txt`.
5. Import `package_ball_import.txt` as the package ball/BGA array using the same column mapping.
6. If the importer requires a different delimiter, use the CSV files in `01_Bump_Maps` and `02_Ball_Map` as source data and export with the delimiter required by the installed build.

## B. Create die/package geometry
1. Create or load die symbols/footprints matching the actual die outline and bump origin.
2. Place D1 and D2 side-by-side with the UCIe interface edges facing each other.
3. Apply the course's required D2 orientation. The generated local D2 grid is mirrored; do not additionally mirror it unless the actual APD placement transform requires that.
4. Create the package outline and BGA field. The 8 mm × 5 mm outline in the project explanation is only a starting placeholder.
5. Check bump-to-ball alignment, die-to-die spacing, edge clearance, and all package keep-outs.

## C. Define nets and constraints
1. Load/create the die-to-die nets listed in `03_Import_Files/ucie_die_to_die_connections.csv`.
2. Ensure D1 TX pins connect to D2 RX pins and vice versa. Do not connect TX-to-TX or RX-to-RX.
3. Define the JTAG, I²C, GPIO and power nets according to the system-level schematic/netlist. The provided BGA map is the course's assignment illustration, not a substitute for an electrical schematic.
4. Add UCIe lane groups, clock groups, valid/track groups and sideband groups.
5. Set target impedance, differential/single-ended rules as appropriate to the UCIe Standard Package electrical model, topology, data rate and stack-up. UCIe mainband signals in this Standard Package description are single-ended unidirectional lanes; do not blindly apply differential-pair rules to TXDATA/RXDATA.
6. Set actual length/skew, spacing, via, neck-down and return-path constraints from the selected data rate and package channel budget.

## D. Route
1. Route UCIe high-speed lanes first, preserving the signal-exit order and per-column grouping from the selected approved bump matrix.
2. Route clock, track and valid nets with their required relationship to the associated data lanes.
3. Route sideband signals next.
4. Route JTAG, I²C and GPIO after high-speed routes.
5. Complete VSS/VCCIO/VCCAON/VCC distribution with sufficient bump/ball and via capacity.
6. Maintain continuous reference planes; avoid reference-plane discontinuities under UCIe routes.
7. Use appropriate via transitions and keep stubs/unused via barrels controlled according to fabrication capability.

## E. Verify and archive
1. Run connectivity and unconnected pin checks.
2. Run full package DRC: spacing, width, clearance, via, copper-to-outline, solder-mask and manufacturing rules.
3. Review plane connectivity and power/ground return paths.
4. Run available SI/channel analysis for insertion loss, return loss, NEXT/FEXT crosstalk, and timing/skew against the selected UCIe target.
5. Fix all errors; document any accepted warnings with justification.
6. Save the native APD database and archive the design technology, libraries, constraint files, reports and final manufacturing outputs.

## Import caution
The course handout gives the column layout but does not identify the exact APD import command/dialog, pin-use vocabulary, coordinate-unit preference, or file header parser settings for every 24.1 installation. Confirm the import options in your installed build. If `BI` is rejected, choose the pin-use code required by the import dialog rather than silently changing the file's meaning.
