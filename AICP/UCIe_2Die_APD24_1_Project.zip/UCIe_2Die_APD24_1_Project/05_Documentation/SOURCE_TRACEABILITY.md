# Source traceability

| Source | Location | Used for |
|---|---|---|
| Course_Project_AICP.pdf | Page 1 | Two-die substrate objective |
| Course_Project_AICP.pdf | Page 3 | UCIe, JTAG, I²C and 16-bit GPIO signal families |
| Course_Project_AICP.pdf | Pages 4–5 | D1 bump-map assignment and D2 mirrored-map instruction |
| Course_Project_AICP.pdf | Page 6 | 40 µm bump, 130 µm bump pitch, 150 µm ball, 400 µm ball pitch |
| Course_Project_AICP.pdf | Page 7 | Six-column text import format; example numeric values ignored |
| Course_Project_AICP.pdf | Page 8 | 10 × 10 illustrative BGA ball-map assignment |
| Course_Project_AICP.pdf | Page 9 | Conceptual two-die package result image |
| UCIE.pdf | Section 5.2.1, printed pages 144–145 | Standard Package x16 signal architecture |
| UCIE.pdf | Table 5-17, printed pages 178–179 | Exact standard-package mainband/sideband signal names |
| UCIE.pdf | Section 5.7.3.1, printed pages 179–180 | Standard-package bump-matrix origin, column and signal-exit guidance |
| UCIE.pdf | Figures 5-33 and 5-34, printed page 180 | Reference x16 bump matrix and two-layer signal exit order |
| UCIE.pdf | Section 5.7.3.2, printed pages 182 onward | Standard and mirrored die-rotate module naming/connection configurations |

## Normalisation
The course map labels such as `d1_gpio[0]` are written as `d1_gpio_0` in the CSV/TXT files to avoid bracket parsing issues in package pin/net import. The UCIe lane names are normalised to lowercase (`d1_txdata0`, etc.). Power net labels are `VSS`, `VCC`, `VCCIO`, and `VCCAON`.
