# Two-die UCIe substrate design — project explanation

## 1. Objective
Create a package/substrate containing two identical chiplets (D1 and D2), a UCIe standard-package x16 die-to-die link, JTAG, I²C and 16 GPIO signals per die, plus a BGA escape interface. The deliverable is a pin-map-driven APD Plus 24.1 implementation workspace.

## 2. What the project brief specifies
From *Course_Project_AICP.pdf*:
- D1 bump map and D2 bump map (D2 shown as a mirror of D1), pages 4–5.
- UCIe mainband and sideband, JTAG (TDI/TDO/TCK/TMS/TRST), I²C (SDA/SCL), and GPIO[15:0], page 3.
- Bump diameter 40 µm, bump pitch 130 µm, ball diameter 150 µm, ball pitch 400 µm, page 6.
- A six-column text import format: Pin Number, X Coord, Y Coord, Net Name, Pin Use, Rotation, page 7.
- A 10 × 10 illustrative ball map, page 8, and the expected two-die package view, page 9.

The supplied maps were transcribed into editable CSV grid files. Empty cells in the bump map are intentionally not exported as pins.

## 3. UCIe reference used
The supplied *UCIE.pdf* is UCIe Specification Revision 1.1, Version 1.0, dated 10 July 2023.
- Section 5.2.1 (printed pages 144–145) describes a Standard Package Module as 16 single-ended data lanes, two clock phases, valid and track in each direction, plus sideband data and clock in each direction.
- Table 5-17 (printed pages 178–179) lists TXDATA[15:0], TXVLD, TXTRK, TXCKP, TXCKN, RXDATA[15:0], RXVLD, RXTRK, RXCKP, RXCKN, TXDATASB, RXDATASB, TXCKSB and RXCKSB.
- Section 5.7.3.1 and Figures 5-33/5-34 (printed pages 179–180) define the x16 Standard Package bump matrix and signal exit order. The spec recommends its matrix, says the lower-left corner is the origin, preserves the signals within each column, and calls for the specified two-layer signal exit order. It also recommends a suitable VSS/VCCIO/VCCAON pattern for crosstalk and power delivery.
- Section 5.7.3.2 (printed pages 182 onward) defines standard-package module naming and mirrored-die-rotate connection cases.

## 4. Design interpretation and important compliance note
The course handout's D1/D2 maps are a course-specific pin assignment, not a verbatim copy of UCIe Figure 5-33. The handout explicitly says D2 is a mirror of D1. This workspace preserves that educational assignment and creates D2 by a horizontal mirror of the D1 logical grid.

Do **not** describe this as proven UCIe-compliant solely because the signal names are present. Before sign-off, compare the placed/rotated D1 and D2 bump matrices against UCIe Figure 5-33, Figure 5-34 and the applicable mirrored-die-rotate case in Section 5.7.3.2. In particular, check per-column lane grouping, Tx/Rx order at the die edge, signal exit order, and supply/ground pattern. If strict compliance is required, replace the course-specific grid with the exact standard matrix and re-export.

## 5. Coordinate conventions
- Bump grid: 14 columns (A–N) × 18 rows. X pitch = Y pitch = 130 µm. Bump diameter = 40 µm.
- Bump local origin: lower-left bump-grid corner, following UCIe Section 5.7.3.1. Row 18 is the bottom row; Column A is the leftmost column. Coordinates are exported in micrometres.
- D2 is horizontally mirrored within the local 14-column grid. Its local origin is still lower-left after mirroring.
- Ball grid: 10 × 10 (A–J), 400 µm pitch, 150 µm ball diameter. Local origin is the lower-left ball-grid corner. The ball assignments follow the handout's illustrative ball-map topology.
- Text files use tab-separated columns matching the example on handout page 7. Select micrometres as the coordinate unit when importing. If your APD import setup expects database units or mils, convert the coordinates before import; do not mix units.

## 6. Pin counts and interfaces
- Each die map exports 125 occupied bump sites (the 14 × 18 logical matrix includes unused/blank sites).
- Each die includes UCIe x16 mainband and sideband, five JTAG signals, two I²C signals and 16 GPIO signals, plus power/ground bumps.
- The ball map exports 100 balls, including both dies' GPIO/JTAG/I²C assignments and VCC, VCCIO, VCCAON and VSS.
- `ucie_die_to_die_connections.csv` is the logical link map: D1 TX connects to D2 RX and D2 TX connects to D1 RX for each data lane, valid, track, clocks and sideband.

## 7. Proposed package organization (initial placement proposal)
Use a rectangular organic substrate with two identical die footprints placed side-by-side and their UCIe edges facing one another. Keep the package BGA centered beneath the die pair. The coordinates in the pin-import files are local pin coordinates; they do not by themselves create the die placements or package outline.

Suggested starting geometry (engineering proposal, not specified by the handout):
- Package outline: 8.0 mm × 5.0 mm.
- Die body envelope: 2.0 mm × 2.5 mm each (must be replaced by actual die dimensions).
- Place D1 and D2 symmetrically around the package centerline, with the UCIe interface edges facing inward.
- BGA: 10 × 10 at 0.4 mm pitch, centered on the package.

These are placeholders for layout bring-up. Obtain actual die dimensions, bump origin/rotation, substrate outline, keep-outs, and ball-map origin from the course/instructor before treating the placement as final.

## 8. Suggested stack-up and routing approach
A starting proposal for APD planning (not a UCIe-mandated stack-up):
1. L1 — die bump escape / short UCIe breakout.
2. L2 — UCIe signal routing.
3. L3 — ground reference plane.
4. L4 — general signal / GPIO / JTAG / I²C routing.
5. L5 — power plane (VCC/VCCIO/VCCAON, split only where appropriate).
6. L6 — BGA escape / bottom routing.

Use continuous reference planes, short return paths, avoid plane splits beneath high-speed routes, keep aggressors separated where possible, and route UCIe lanes with matched topology/length according to the actual target data rate and channel budget. Do not invent a length tolerance: obtain the selected UCIe data rate and channel loss/crosstalk budget, then constrain the design accordingly. The handout does not specify data rate, stack-up materials, dielectric thickness, copper thickness, via technology, impedance, or length tolerance.

## 9. What constitutes completion
The generated files complete the *data-preparation portion*: pin maps, coordinates, logical connectivity, and import-ready tab files. A real physical-design completion additionally requires, inside Allegro X APD Plus 24.1:
1. Create the package/substrate database and layer stack-up.
2. Create/import die bump arrays and BGA balls using the supplied text files.
3. Place and orient both dies; verify bump-to-ball coordinate transforms.
4. Define nets and connect the die-to-die UCIe logical links.
5. Set up constraints and route the UCIe lanes and low-speed I/O.
6. Complete power/ground distribution and via transitions.
7. Run DRC, connectivity, unconnected pin, short, spacing, and any available signal-integrity/channel checks.
8. Save the native APD database and export manufacturing outputs only after all checks pass.

No Allegro database, routed geometry, DRC report, or SI report is included because the proprietary APD application and its licensed routing/sign-off environment are not available in this workspace.
