#!/usr/bin/env python3
"""Basic structural checks for the pin-map/import data; not an Allegro DRC."""
from pathlib import Path
import csv, sys

ROOT = Path(__file__).resolve().parents[1]
IMP = ROOT / "03_Import_Files"
EXPECTED_HEADER = ["Pin Number","X Coord","Y Coord","Net Name","Pin Use","Rotation"]

def read_import(path):
    with path.open(encoding="utf-8") as f:
        lines = [line.rstrip("\n") for line in f if line.strip()]
    header = lines[0].split("\t")
    assert header == EXPECTED_HEADER, f"{path.name}: unexpected header {header}"
    data = [line.split("\t") for line in lines[1:]]
    assert all(len(row) == 6 for row in data), f"{path.name}: malformed row"
    nums = [int(row[0]) for row in data]
    assert nums == list(range(1, len(nums)+1)), f"{path.name}: pin numbering not sequential"
    assert len({(row[1],row[2]) for row in data}) == len(data), f"{path.name}: duplicate coordinates"
    assert all(row[4] == "BI" and row[5] == "0" for row in data), f"{path.name}: unexpected pin-use/rotation"
    return data

def check():
    d1 = read_import(IMP/"D1_bump_import.txt")
    d2 = read_import(IMP/"D2_bump_import.txt")
    balls = read_import(IMP/"package_ball_import.txt")
    assert len(d1) == 125, f"D1 expected 125 occupied bumps, got {len(d1)}"
    assert len(d2) == 125, f"D2 expected 125 occupied bumps, got {len(d2)}"
    assert len(balls) == 100, f"BGA expected 100 balls, got {len(balls)}"
    for die, data in [("D1",d1),("D2",d2)]:
        nets = [r[3] for r in data]
        for i in range(16):
            assert f"{die.lower()}_txdata{i}" in nets
            assert f"{die.lower()}_rxdata{i}" in nets
            assert f"{die.lower()}_gpio_{i}" in nets
        for net in [f"{die.lower()}_txvld",f"{die.lower()}_rxvld",
                    f"{die.lower()}_txtrk",f"{die.lower()}_rxtrk",
                    f"{die.lower()}_txckp",f"{die.lower()}_txckn",
                    f"{die.lower()}_rxckp",f"{die.lower()}_rxckn",
                    f"{die.lower()}_txdatasb",f"{die.lower()}_rxdatasb",
                    f"{die.lower()}_txcksb",f"{die.lower()}_rxcksb"]:
            assert net in nets, f"{die}: missing {net}"
    print("PASS: import headers, sequential pin numbers, unique coordinates and expected interface pins")
    print(f"D1 bumps: {len(d1)} | D2 bumps: {len(d2)} | BGA balls: {len(balls)}")
    print("NOTE: structural data validation only; not APD DRC, connectivity, routing or SI verification.")

if __name__ == "__main__":
    check()
