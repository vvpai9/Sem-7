#!/usr/bin/env python3
"""Regenerate APD import text files from editable grid CSVs.
Coordinates are exported in micrometres, lower-left origin.
"""
from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parents[1]
COLS = list("ABCDEFGHIJKLMN")

def export_grid(csv_path, out_path, pitch, ncols):
    rows = list(csv.reader(csv_path.open(newline="", encoding="utf-8")))
    header = rows[0][1:]
    entries = []
    for row_idx, row in enumerate(rows[1:], start=1):
        logical_row = int(row[0])
        for col_idx, net in enumerate(row[1:]):
            net = net.strip()
            if not net:
                continue
            x = col_idx * pitch
            y = (len(rows) - 2 - (logical_row - 1)) * pitch
            entries.append((x, y, net))
    with out_path.open("w", encoding="utf-8", newline="") as f:
        f.write("Pin Number\tX Coord\tY Coord\tNet Name\tPin Use\tRotation\n")
        for pin, (x, y, net) in enumerate(entries, start=1):
            f.write(f"{pin}\t{x}\t{y}\t{net}\tBI\t0\n")
    return len(entries)

def export_ball_grid(csv_path, out_path, pitch=400):
    rows = list(csv.reader(csv_path.open(newline="", encoding="utf-8")))
    entries = []
    nrows = len(rows) - 1
    for r, row in enumerate(rows[1:]):
        for c, net in enumerate(row[1:]):
            net = net.strip()
            if net:
                entries.append((c*pitch, (nrows-1-r)*pitch, net))
    with out_path.open("w", encoding="utf-8", newline="") as f:
        f.write("Pin Number\tX Coord\tY Coord\tNet Name\tPin Use\tRotation\n")
        for pin, (x, y, net) in enumerate(entries, start=1):
            f.write(f"{pin}\t{x}\t{y}\t{net}\tBI\t0\n")
    return len(entries)

if __name__ == "__main__":
    imp = ROOT / "03_Import_Files"
    d1 = export_grid(ROOT/"01_Bump_Maps/D1_bump_grid.csv", imp/"D1_bump_import.txt", 130, 14)
    d2 = export_grid(ROOT/"01_Bump_Maps/D2_bump_grid.csv", imp/"D2_bump_import.txt", 130, 14)
    balls = export_ball_grid(ROOT/"02_Ball_Map/package_ball_grid.csv", imp/"package_ball_import.txt", 400)
    print(f"Generated D1={d1}, D2={d2}, balls={balls}")
