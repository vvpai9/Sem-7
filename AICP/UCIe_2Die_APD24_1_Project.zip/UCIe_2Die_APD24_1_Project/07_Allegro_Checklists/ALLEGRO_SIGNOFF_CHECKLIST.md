# APD Plus 24.1 sign-off checklist

## Before import
- [ ] Confirm project technology file and database units.
- [ ] Confirm the APD import parser accepts tab-separated six-column files.
- [ ] Confirm `BI` is an accepted pin-use code.
- [ ] Confirm actual die dimensions, bump origin, die rotation and package outline.
- [ ] Confirm BGA ball numbering and system-level schematic.

## Pin-map import
- [ ] Import D1 bump file; verify 125 pins and net names.
- [ ] Import D2 bump file; verify 125 pins and local mirror orientation.
- [ ] Import package ball file; verify 100 balls.
- [ ] Verify coordinates are interpreted in µm (not mils).
- [ ] Check no duplicate pin coordinates and no unintended pin overlap.

## UCIe topology
- [ ] Confirm D1 TXDATA[15:0] → D2 RXDATA[15:0].
- [ ] Confirm D2 TXDATA[15:0] → D1 RXDATA[15:0].
- [ ] Confirm valid, track, clocks and sideband directions.
- [ ] Review x16 standard-package column grouping and signal-exit order against UCIe Figures 5-33/5-34.
- [ ] Confirm applicable mirrored-die-rotate module orientation under UCIe Section 5.7.3.2.

## Physical design
- [ ] Define approved layer stack-up and material properties.
- [ ] Define impedance, width/space, via and length/skew constraints.
- [ ] Place dies and BGA using verified package geometry.
- [ ] Route high-speed UCIe nets first, then sideband, JTAG/I²C/GPIO.
- [ ] Complete VSS/VCC/VCCIO/VCCAON power distribution.
- [ ] Preserve continuous return planes under high-speed routes.

## Verification and release
- [ ] Connectivity and unconnected-pin checks pass.
- [ ] Package DRC passes or all warnings are dispositioned.
- [ ] SI/channel analysis meets selected UCIe rate and channel budget.
- [ ] Power integrity and return-current paths reviewed.
- [ ] Save native APD database and archive libraries/tech/constraints.
- [ ] Export manufacturing files only after sign-off.
