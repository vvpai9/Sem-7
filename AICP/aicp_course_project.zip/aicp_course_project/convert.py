import csv					
rows = list(csv.reader(open("ballmap.csv", encoding="utf-8-sig")))					
out = ["Pin Number\tX Coord\tY Coord\tNet Name\tPin Use\tRotation"]					
n = 1					
for r, row in enumerate(rows):					
	for c, cell in enumerate(row):					
		if cell.strip():					
			out.append(f"{n}\t{c*400}\t{(len(rows)-1-r)*400}\t{cell.strip()}\tBI\t0")					
			n += 1					
open("balls.txt", "w").write("\n".join(out))					
